//
//  Tech_Case_BluetoothApp.swift
//  Tech Case Bluetooth
//
//  Created by Jasmin Hachmane on 24/02/2025.
//

import SwiftUI

@main
struct Tech_Case_BluetoothApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
